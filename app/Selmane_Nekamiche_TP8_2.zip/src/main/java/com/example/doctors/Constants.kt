package com.example.doctors

val baseUrl= "https://c4e3d98920fa.ngrok.io/"