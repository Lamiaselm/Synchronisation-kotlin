package com.example.doctors

class UrlImage {
companion object{
    val url="https://0dee707d1181.ngrok.io/"

}
}