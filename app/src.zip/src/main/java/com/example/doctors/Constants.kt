package com.example.doctors

val baseUrl= "https://94f23b83e05b.ngrok.io/"