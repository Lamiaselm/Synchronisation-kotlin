package com.example.doctors

class UrlImage {
companion object{
    val url="https://94f23b83e05b.ngrok.io/"

}
}