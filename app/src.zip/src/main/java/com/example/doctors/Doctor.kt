package com.example.doctors

data class Doctor(  val nom:String, val prenom:String, val num:String,
                    val speciality:String, val img:String, val lat: Double, val lang: Double
)