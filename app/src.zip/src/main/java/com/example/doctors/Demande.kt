package com.example.doctors

import java.time.LocalDate
import java.time.LocalTime

data class Demande(
    val obj:String,
    val msg:String,
    val idmed:Int
)